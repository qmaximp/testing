document.addEventListener('DOMContentLoaded', function () {
    const nationalityAll = document.querySelector('#nationality');
    const yearElem = document.querySelector('#selectYear');
    const dayElem = document.querySelector('#selectDay');
    const monthElem = document.querySelector('#selectMonth');
    let nationality = ["Russian", "American", "Ukrainian", "Slovak / Slovakian", "Romanian", "Belarusian", "July",
        "Mexican", "Canadian", "French", "German", "British / English"];
    let nr = 12;
    let days = 31;
    let mr = ["January", "February", "March", "April", "May", "June", "July",
        "August", "September", "October", "November", "December"];
    let months = 12;
    let yearStart = (yearElem.getAttribute("start")) ? yearElem.getAttribute("start") : 1900;
    let yearEnd = (yearElem.getAttribute("end")) ? yearElem.getAttribute("end") : 2023;
    let n = 1;
    while (n <= nr) {
        const opt = document.createElement("option");
        opt.setAttribute("value", n);
        opt.innerText = nationality[n - 1];
        nationalityAll.appendChild(opt);
        ++n;
    }
    let d = 1;
    while (d <= days) {
        const opt = document.createElement("option");
        opt.setAttribute("value", d);
        opt.innerText = d;
        dayElem.appendChild(opt);
        ++d;
    }
    let m = 1;
    while (m <= months) {
        const opt = document.createElement("option");
        opt.setAttribute("value", m);
        opt.innerText = mr[m - 1];
        monthElem.appendChild(opt);
        ++m;
    }
    while (yearStart <= yearEnd) {
        const opt = document.createElement("option");
        opt.setAttribute("value", yearStart);
        opt.innerText = yearStart;
        yearElem.appendChild(opt);
        ++yearStart;
    }
    //build days
    function buildDays(length) {
        let daysArry = [];
        let d = 1;
        while (d <= 31) {
            daysArry.push(d);
            ++d;
        }
        daysArry.length = (daysArry.length - length);
        dayElem.innerHTML = '';
        daysArry.forEach(d => {
            const opt = document.createElement("option");
            opt.setAttribute("value", d);
            opt.innerText = d;
            dayElem.appendChild(opt);
        });
    }
    //check selected month
    function checkMonth(month) {
        let len = 0;
        switch (month) {
            case "9":
                len = 1;
                break;
            case "4":
                len = 1;
                break;
            case "6":
                len = 1;
                break;
            case "11":
                len = 1;
                break;
            default:
                len = 0;
                break;
        }
        if (month == 2) {
            checkLeapYear(yearElem.value);
        } else {
            buildDays(len);
        }
    }
    //check leap year
    function checkLeapYear(year) {
        let v = (year / 4) * 1;
        if (/^[0-9]+$/.test(v)) {
            (monthValue == 2) ?
                buildDays(2) //29 days
                : '';
        } else {
            (monthValue == 2) ?
                buildDays(3)
                : '';
        }
    }
    //Month Element Event Listener
    var monthValue = 0
    monthElem.addEventListener('click', function () {
        if (monthValue !== this.value) {
            monthValue = this.value;
            checkMonth(this.value);
        }
    });
    //Year Element Event Listener
    var yearValue = 0;
    yearElem.addEventListener('click', function () {
        yearValue = this.value;
        checkLeapYear(this.value);
    });


    document.querySelector(".mainForm").addEventListener(("submit"), subm)

    function subm(e) {
        e.preventDefault()
        //Validation
        let firstNameValid = valid(document.querySelector("#firstName"), { minlenght: 3 })
        console.log(firstNameValid)
        if (firstNameValid == false) {
            document.querySelector("#firstName").classList.add("errorValid")
            document.querySelector("#firstNameSpan").classList.remove("successValid")
            badsub()
            return false;
        }
        else {
            document.querySelector("#firstNameSpan").classList.add("successValid")
            document.querySelector("#firstName").classList.remove("errorValid")
        }
        let flastNameValid = valid(document.querySelector("#lastName"), { minlenght: 3 })
        if (flastNameValid == false) {
            document.querySelector("#lastName").classList.add("errorValid")
            document.querySelector("#lastNameSpan").classList.remove("successValid")
            badsub()
            return false;
        }
        else {
            document.querySelector("#lastNameSpan").classList.add("successValid")
            document.querySelector("#lastName").classList.remove("errorValid")
        }
        let emailValid = valid(document.querySelector("#email"), { minlenght: 3 })
        if (emailValid == false) {
            document.querySelector("#email").classList.add("errorValid")
            document.querySelector("#emailSpan").classList.remove("successValid")
            badsub()
            return false;
        }
        else {
            document.querySelector("#emailSpan").classList.add("successValid")
            document.querySelector("#email").classList.remove("errorValid")
        }


        let passes = [document.querySelector("#password"), document.querySelector("#passwordConf")]
        if (passes[0].value == passes[1].value) {

            document.querySelector(".mainBlock").innerHTML = `
        <div class="regedForm">
            <div class="regdHeader"><h2>Thank you!</h2>
            <p class="regdtext">you registered!</p></div>
            <div class="regFooter">
                    <p>Have an account?
                        <a href="#">
                            Login
                        </a>
                    </p>
            </div>
            </div>
        `
        }
        else {
            document.querySelector("#subButton").classList.add("invalidButton")
            setTimeout((ev) => {
                document.querySelector("#subButton").classList.remove("invalidButton")
            }, 500)
            passes[0].classList.add("errorValid")
            passes[1].classList.add("errorValid")
        }
    }
    function valid(inp, params) {
        if (params.minlenght) {
            if (inp.value.length < params.minlenght) {
                document.querySelector("#subButton").classList.add("invalidButton")
                return false;
            }
        }
        return true;
    }

    function badsub() {
        document.querySelector("#subButton").classList.add("invalidButton")
        setTimeout((ev) => {
            document.querySelector("#subButton").classList.remove("invalidButton")
        }, 500)
    }
})

myInput.onfocus = function () {
    document.getElementById("message").style.display = "block";
}

// Когда пользователь щелкает за пределами поля пароля, скройте окно сообщения
myInput.onblur = function () {
    document.getElementById("message").style.display = "none";
}
myInput.onkeyup = function () {
    // Validate lowercase letters
    var lowerCaseLetters = /[a-z]/g;
    if (myInput.value.match(lowerCaseLetters)) {
        letter.classList.remove("invalid");
        letter.classList.add("valid");
    } else {
        letter.classList.remove("valid");
        letter.classList.add("invalid");
    }

    // Проверка заглавных букв
    var upperCaseLetters = /[A-Z]/g;
    if (myInput.value.match(upperCaseLetters)) {
        capital.classList.remove("invalid");
        capital.classList.add("valid");
    } else {
        capital.classList.remove("valid");
        capital.classList.add("invalid");
    }

    // Проверка чисел
    var numbers = /[0-9]/g;
    if (myInput.value.match(numbers)) {
        number.classList.remove("invalid");
        number.classList.add("valid");
    } else {
        number.classList.remove("valid");
        number.classList.add("invalid");
    }

    // Проверка длины
    if (myInput.value.length >= 8) {
        length.classList.remove("invalid");
        length.classList.add("valid");
    } else {
        length.classList.remove("valid");
        length.classList.add("invalid");
    }
}

